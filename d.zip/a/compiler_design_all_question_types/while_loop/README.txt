COMPILER DESIGN LAB — WHILE LOOP
=================================

SAMPLE INPUT
------------
while (m < n * 4)
{
    r = 16 * 5;
    s = x * y + z;
    t = m + s;
}


FILES
-----
lexer.l       Flex/LEX token rules
parser.y      Bison/YACC grammar and semantic actions
sample.cmini  Input program
optimize.c    C optimization-stage starter
target.c      C target-code-generation-stage starter
README.txt    Full execution guide

REQUIREMENTS
------------
GCC, Flex, and Bison. GCC is assumed installed.
Check Flex/Bison availability:
    flex --version
    bison --version

LINUX EXECUTION — RUN IN THIS ORDER
-----------------------------------
1. Generate parser source and header:
       bison -d parser.y
2. Generate lexer C source:
       flex lexer.l
3. Compile the integrated lexer/parser:
       gcc -D_POSIX_C_SOURCE=200809L parser.tab.c lex.yy.c -o compiler -lfl
4. Run the sample and save TAC:
       ./compiler < sample.cmini > tac.txt
5. Inspect TAC:
       cat tac.txt
6. Compile the C optimizer:
       gcc optimize.c -o optimize
7. Run it:
       ./optimize
       cat optimized_tac.txt
8. Compile the C backend:
       gcc target.c -o target
9. Run it and inspect output:
       ./target
       cat target_code.txt

QUESTION MAPPING
----------------
(a) lexer.l identifies keywords, identifiers, numbers, operators, and punctuation.
(b) parser.y checks whether the supplied input matches its grammar.
(c) Semantic actions in parser.y emit three-address code (TAC).
(d) optimize.c is a starter that currently copies TAC unchanged. Implement:
    For the original while example, move n * 4 before the loop only if n is not changed in the body. Fold 16 * 5 into 80.
(e) target.c is a starter that preserves TAC for inspection. A backend should
    translate instructions into pseudo-assembly, for example:
       x = a       -> MOV x, a
       t1 = a + b  -> MOV t1, a; ADD t1, b
       t2 = a * b  -> MOV t2, a; MUL t2, b
       goto L1     -> JMP L1
       conditional branch -> CMP plus an appropriate conditional jump
(f) Integration pipeline:
    sample.cmini -> Flex -> Bison/SDT -> tac.txt -> optimize.c
    -> optimized_tac.txt -> target.c -> target_code.txt

IMPORTANT LIMITATIONS
---------------------
This is a learning starter package, not a complete general-purpose compiler.
The parser grammar is intentionally limited to the sample's shape. The optimizer
and backend are starter programs and do not yet perform real optimization or
general TAC translation. Do not claim questions (d) and (e) are fully implemented
until you extend and test those C files. Each stage's execution is included so
you can build and study the modules one at a time.
