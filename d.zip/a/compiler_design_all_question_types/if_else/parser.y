%{
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int yylex(void);
void yyerror(const char *s);
static int temp_no = 0;
static char *newtemp(void) {
    char b[32];
    snprintf(b, sizeof b, "t%d", ++temp_no);
    return strdup(b);
}
%}
%union { int num; char *str; }
%token WHILE IF ELSE FOR LBRACE RBRACE LPAREN RPAREN SEMICOLON ASSIGN LE GE EQ NE LT GT PLUS MINUS MUL DIV INVALID
%token <num> NUMBER
%token <str> ID
%type <str> expr
%left PLUS MINUS
%left MUL DIV
%%

program: IF LPAREN ID LT ID RPAREN
        { printf("ifFalse %s < %s goto L1\n", $3, $5); }
        LBRACE assignment RBRACE
        { printf("goto L2\nL1:\n"); }
        ELSE LBRACE assignment RBRACE
        { printf("L2:\nSyntax is correct.\n"); }
      ;
assignment: ID ASSIGN expr SEMICOLON { printf("%s = %s\n", $1, $3); } ;

expr: expr PLUS expr { char *t=newtemp(); printf("%s = %s + %s\n",t,$1,$3); $$=t; }
    | expr MINUS expr { char *t=newtemp(); printf("%s = %s - %s\n",t,$1,$3); $$=t; }
    | expr MUL expr { char *t=newtemp(); printf("%s = %s * %s\n",t,$1,$3); $$=t; }
    | expr DIV expr { char *t=newtemp(); printf("%s = %s / %s\n",t,$1,$3); $$=t; }
    | LPAREN expr RPAREN { $$=$2; }
    | ID { $$=$1; }
    | NUMBER { char b[32]; snprintf(b,sizeof b,"%d",$1); $$=strdup(b); }
    ;
%%
void yyerror(const char *s) { fprintf(stderr, "Syntax error: %s\n", s); }
int main(void) { printf("Three-address code (TAC):\n"); return yyparse() ? 1 : 0; }
