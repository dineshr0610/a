/* C optimization-stage starter: copies TAC so each stage can be tested. */
#include <stdio.h>
int main(void) {
    FILE *in=fopen("tac.txt","r"), *out=fopen("optimized_tac.txt","w");
    int c;
    if(!in){perror("tac.txt");return 1;}
    if(!out){perror("optimized_tac.txt");fclose(in);return 1;}
    while((c=fgetc(in))!=EOF) fputc(c,out);
    fclose(in); fclose(out);
    puts("Starter optimization pass completed: TAC copied unchanged.");
    puts("Implement the transformation described in README before claiming optimization.");
    return 0;
}
