COMPILER DESIGN LAB — COMPLETE GUIDE FOR QUESTIONS (a) TO (f)
==============================================================

INPUT
-----
while (m < n * 4)
{
    r = 16 * 5;
    s = x * y + z;
    t = m + s;
}

FILES
-----
lexer.l              LEX/FLEX token rules (question a)
parser.y             YACC/BISON syntax grammar and SDT TAC actions (b and c)
sample.cmini         Sample input program
optimize.py          Code motion and constant folding (d)
target.py            Pseudo-assembly generator (e)
README_ALL_STEPS.txt This explanation and execution guide

REQUIREMENTS
------------
GCC is assumed installed. Flex and Bison must also be available:
    flex --version
    bison --version

RUN EVERYTHING IN LINUX
-----------------------
Keep all files in one folder. If using the ZIP, extract it and open a terminal
inside the extracted folder.

1. Generate parser files:
       bison -d parser.y
       flex lexer.l

2. Compile the integrated LEX/YACC program:
       gcc -D_POSIX_C_SOURCE=200809L parser.tab.c lex.yy.c -o compiler -lfl

3. Run the compiler on the sample:
       ./compiler < sample.cmini > tac.txt

   TAC is saved to tac.txt. "Syntax is correct." appears in the terminal.
   If the input has invalid syntax, a syntax error is reported.

4. See the unoptimized three-address code:
       cat tac.txt

5. Optimize TAC:
       python3 optimize.py

6. See optimized TAC:
       cat optimized_tac.txt

7. Generate target-style code:
       python3 target.py

8. See target code:
       cat target_code.txt

QUESTION (a): LEX
-----------------
lexer.l recognizes keywords, punctuation, operators, integers, and identifiers.
For example, `while` becomes WHILE, `m` becomes ID, `4` becomes NUMBER, and
`*` becomes MUL. Spaces/newlines are ignored.

QUESTION (b): YACC
------------------
parser.y describes valid statement forms: assignments and a while-loop with a
condition and a block. Bison checks whether the token sequence matches these
grammar rules. A missing semicolon or brace should cause a syntax error.

QUESTION (c): SDT / TAC
-----------------------
Semantic actions inside parser.y print intermediate instructions. An expression
like `x * y + z` becomes:
    t4 = x * y
    t5 = t4 + z
    s = t5

TAC uses temporary variables so each instruction performs one small operation.

QUESTION (d): OPTIMIZATION
--------------------------
The optimizer demonstrates:
- Loop-invariant code motion: `t1 = n * 4` is moved before label L1 because
  `n` is not assigned inside this loop body.
- Constant folding: `16 * 5` becomes `80`, so `r = t3` becomes `r = 80`.

Moving an expression outside a loop is safe only if its operands are not changed
inside the loop and moving it does not change program behavior.

QUESTION (e): BACK END
----------------------
target.py maps TAC to educational pseudo-assembly such as MOV, MUL, ADD, CMP,
JGE, and JMP. These are illustrative instructions, not actual machine code for
a specific processor.

QUESTION (f): INTEGRATION
-------------------------
FLEX turns source characters into tokens. BISON parses the tokens and checks
syntax. Its semantic actions generate TAC. optimize.py optimizes TAC. target.py
translates the optimized TAC into target-style instructions.

EXPECTED TAC BEFORE OPTIMIZATION
--------------------------------
L1:
t1 = n * 4
t2 = m < t1
ifFalse t2 goto L2
t3 = 16 * 5
r = t3
t4 = x * y
t5 = t4 + z
s = t5
t6 = m + s
t = t6
goto L1
L2:

EXPECTED OPTIMIZED TAC
----------------------
t1 = n * 4
L1:
t2 = m < t1
ifFalse t2 goto L2
r = 80
t4 = x * y
t5 = t4 + z
s = t5
t6 = m + s
t = t6
goto L1
L2:

EXPECTED TARGET-CODE SHAPE
--------------------------
MOV t1, n
MUL t1, 4
L1:
CMP m, t1
JGE L2
MOV r, #80
MOV t4, x
MUL t4, y
MOV t5, t4
ADD t5, z
MOV s, t5
MOV t6, m
ADD t6, s
MOV t, t6
JMP L1
L2:

TEST A SYNTAX ERROR
-------------------
Copy the input and remove a semicolon or a closing brace:
    cp sample.cmini bad_sample.cmini
    nano bad_sample.cmini
Then run:
    ./compiler < bad_sample.cmini

BEGINNER SUMMARY
----------------
LEX: characters -> tokens
YACC: tokens -> syntax validation
SDT: syntax-rule actions -> TAC
Optimizer: TAC -> improved TAC
Back end: optimized TAC -> target-like instructions

LIMITATIONS
-----------
This is a lab-sized teaching implementation for the supplied single-loop input.
It uses fixed labels L1/L2 and is not designed for nested or multiple loops.
The optimizer only handles the simple patterns used in this experiment. The
target instructions are illustrative pseudo-assembly, not a real CPU executable.
