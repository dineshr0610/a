#!/usr/bin/env python3
"""Teaching optimizer: loop-invariant code motion + constant folding."""
import re
from pathlib import Path

src = Path("tac.txt")
out = Path("optimized_tac.txt")
if not src.exists():
    raise SystemExit("Missing tac.txt. First run: ./compiler < sample.cmini > tac.txt")
lines = [x.strip() for x in src.read_text().splitlines() if x.strip()]
try:
    start, end = lines.index("L1:"), lines.index("L2:")
except ValueError:
    raise SystemExit("Expected L1: and L2: labels in tac.txt")

body = lines[start + 1:end]
assigned = set()
for line in body:
    m = re.match(r"([A-Za-z_]\w*)\s*=", line)
    if m:
        assigned.add(m.group(1))

moved = []
remaining = list(lines)
for line in body:
    m = re.fullmatch(r"(t\d+)\s*=\s*([A-Za-z_]\w*)\s*\*\s*(\d+|[A-Za-z_]\w*)", line)
    if m:
        temp, left, right = m.groups()
        # The source variable operands must not be changed in the loop body.
        vars_used = [v for v in (left, right) if not v.isdigit()]
        if all(v not in assigned for v in vars_used):
            moved.append(line)
            remaining.remove(line)
            break

constants = {}
folded = []
for line in remaining:
    m = re.fullmatch(r"(t\d+)\s*=\s*(-?\d+)\s*([+*])\s*(-?\d+)", line)
    if m:
        temp, a, op, b = m.groups()
        value = int(a) + int(b) if op == "+" else int(a) * int(b)
        constants[temp] = value
        folded.append(f"{temp} = {value}")
    else:
        folded.append(line)

# Replace direct uses of folded constants and omit their temporary definitions.
final = []
for line in folded:
    m = re.fullmatch(r"([A-Za-z_]\w*)\s*=\s*(t\d+)", line)
    if m and m.group(2) in constants:
        final.append(f"{m.group(1)} = {constants[m.group(2)]}")
    elif re.fullmatch(r"(t\d+)\s*=\s*-?\d+", line) and line.split(" = ")[0] in constants:
        temp = line.split(" = ")[0]
        if any(re.fullmatch(r"[A-Za-z_]\w*\s*=\s*" + re.escape(temp), x) for x in folded):
            continue
        final.append(line)
    else:
        final.append(line)

i = final.index("L1:")
final[i:i] = moved
out.write_text("\n".join(final) + "\n")
print("Optimized TAC written to optimized_tac.txt")
print("-----------------------------------------")
print(out.read_text(), end="")
