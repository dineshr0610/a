%{
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int yylex(void);
void yyerror(const char *message);
static int temp_count = 0;
static char *new_temp(void) {
    char buffer[32];
    snprintf(buffer, sizeof(buffer), "t%d", ++temp_count);
    return strdup(buffer);
}
%}
%union { int num; char *str; }
%token WHILE LPAREN RPAREN LBRACE RBRACE SEMICOLON ASSIGN LT PLUS MUL INVALID
%token <num> NUMBER
%token <str> ID
%type <str> expr condition
%left PLUS
%left MUL
%%
program : statement_list ;
statement_list : statement | statement_list statement ;
statement : assignment | while_statement ;
assignment
    : ID ASSIGN expr SEMICOLON { printf("%s = %s\n", $1, $3); }
    ;
while_statement
    : WHILE { printf("L1:\n"); }
      LPAREN condition RPAREN
      { printf("ifFalse %s goto L2\n", $4); }
      LBRACE statement_list RBRACE
      { printf("goto L1\nL2:\n"); }
    ;
condition
    : expr LT expr {
        char *t = new_temp();
        printf("%s = %s < %s\n", t, $1, $3);
        $$ = t;
      }
    ;
expr
    : expr PLUS expr {
        char *t = new_temp();
        printf("%s = %s + %s\n", t, $1, $3);
        $$ = t;
      }
    | expr MUL expr {
        char *t = new_temp();
        printf("%s = %s * %s\n", t, $1, $3);
        $$ = t;
      }
    | LPAREN expr RPAREN { $$ = $2; }
    | ID { $$ = $1; }
    | NUMBER {
        char buffer[32];
        snprintf(buffer, sizeof(buffer), "%d", $1);
        $$ = strdup(buffer);
      }
    ;
%%
void yyerror(const char *message) {
    fprintf(stderr, "Syntax error: %s\n", message);
}
int main(void) {
    if (yyparse() == 0) {
        fprintf(stderr, "Syntax is correct.\n");
        return 0;
    }
    return 1;
}
