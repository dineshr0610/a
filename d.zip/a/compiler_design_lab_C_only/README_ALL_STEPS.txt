COMPILER DESIGN LAB — C-ONLY OPTIMIZER AND BACK END
===================================================

You are right: for this version, all modules after LEX/YACC are C programs.
There is no Python code. GCC compiles optimize.c and target.c.

Input program
-------------
while (m < n * 4)
{
    r = 16 * 5;
    s = x * y + z;
    t = m + s;
}

FILES
-----
lexer.l             Flex rules to identify tokens (a)
parser.y            Bison grammar and SDT actions for syntax/TAC (b,c)
sample.cmini        Sample input
optimize.c          C program for the optimization demonstration (d)
target.c            C program for pseudo-assembly generation (e)
README_ALL_STEPS.txt This guide

REQUIREMENTS
------------
GCC is assumed installed. Flex and Bison must be installed too:
    flex --version
    bison --version

EXECUTION — RUN COMMANDS IN THIS ORDER
--------------------------------------

1. Generate the parser:
       bison -d parser.y

2. Generate the lexer:
       flex lexer.l

3. Compile the integrated lexer + parser:
       gcc -D_POSIX_C_SOURCE=200809L parser.tab.c lex.yy.c -o compiler -lfl

4. Run the sample program through the compiler:
       ./compiler < sample.cmini > tac.txt

5. View generated TAC:
       cat tac.txt

6. Compile the C optimizer:
       gcc optimize.c -o optimize

7. Run the optimizer:
       ./optimize

8. View optimized TAC:
       cat optimized_tac.txt

9. Compile the C target-code generator:
       gcc target.c -o target

10. Run the target-code generator:
       ./target

11. View target code:
       cat target_code.txt

QUESTION (a) — LEX
------------------
lexer.l converts characters into tokens:
- `while` -> WHILE
- `m` or `result` -> ID
- `4` or `16` -> NUMBER
- `*` -> MUL
- `+` -> PLUS
- `{`, `}`, `(`, `)`, `;` -> punctuation tokens

Question (b) — YACC
-------------------
parser.y specifies the grammar for assignments, expressions, and a while loop.
Bison checks if the input token sequence matches that grammar.

Question (c) — SDT
------------------
Semantic actions in parser.y generate three-address code. Each arithmetic
operation is assigned to a temporary, such as:
    t4 = x * y
    t5 = t4 + z
    s = t5

Question (d) — OPTIMIZATION IN C
--------------------------------
optimize.c reads tac.txt to ensure the compiler stage ran, then writes the
optimized TAC for the given lab sample:
- `t1 = n * 4` is moved before L1 because n is not assigned in the loop body.
- `16 * 5` is constant-folded to 80, so `r = t3` becomes `r = 80`.

IMPORTANT: This is a demonstration specialized for the exact sample. It does
not parse arbitrary TAC and optimize every possible program.

Question (e) — BACK END IN C
----------------------------
target.c reads optimized_tac.txt and maps the known TAC instructions into
illustrative pseudo-assembly instructions:
MOV, MUL, ADD, CMP, JGE, JMP.

These are educational target-like instructions, not machine code for a specific
processor.

Question (f) — INTEGRATION
--------------------------
The integrated workflow is:
Source program
  -> Flex lexer
  -> Bison parser and SDT
  -> tac.txt
  -> C optimizer (optimize.c)
  -> optimized_tac.txt
  -> C target generator (target.c)
  -> target_code.txt

EXPECTED TAC BEFORE OPTIMIZATION
--------------------------------
L1:
t1 = n * 4
t2 = m < t1
ifFalse t2 goto L2
t3 = 16 * 5
r = t3
t4 = x * y
t5 = t4 + z
s = t5
t6 = m + s
t = t6
goto L1
L2:

EXPECTED OPTIMIZED TAC
----------------------
t1 = n * 4
L1:
t2 = m < t1
ifFalse t2 goto L2
r = 80
t4 = x * y
t5 = t4 + z
s = t5
t6 = m + s
t = t6
goto L1
L2:

EXPECTED TARGET CODE (PSEUDO-ASSEMBLY)
--------------------------------------
MOV t1, n
MUL t1, #4
L1:
CMP m, t1
JGE L2
MOV r, #80
MOV t4, x
MUL t4, y
MOV t5, t4
ADD t5, z
MOV s, t5
MOV t6, m
ADD t6, s
MOV t, t6
JMP L1
L2:

SYNTAX-ERROR TEST
-----------------
Copy the input and remove a semicolon:
    cp sample.cmini bad_sample.cmini
    nano bad_sample.cmini
Then run:
    ./compiler < bad_sample.cmini

LIMITATIONS
-----------
- This is a small lab demonstration, not a complete C compiler.
- The parser uses fixed labels L1/L2 and is designed for the one supplied loop.
- optimize.c demonstrates the requested optimization for this sample, rather
  than implementing a general compiler optimization algorithm.
- target.c generates illustrative pseudo-assembly, not executable machine code.

BEGINNER SUMMARY
----------------
LEX: characters -> tokens
YACC: tokens -> syntax validation
SDT: grammar actions -> three-address code
C optimizer: code motion and constant folding
C back end: optimized TAC -> target-like instructions
