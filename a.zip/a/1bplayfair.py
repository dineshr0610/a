from CryptoC import Playfair, HillCipher

playfair = Playfair("KEYWORD")

encrypted = playfair.encrypt("HELLO")

print(encrypted)
decrypted = playfair.decrypt(encrypted)


"""# Playfair Cipher - Encryption and Decryption


# Create 5 x 5 key matrix
def create_matrix(key):

    key = key.upper()

    # Replace J with I
    key = key.replace("J", "I")

    # Remove spaces and non-alphabet characters
    key = "".join(char for char in key if char.isalpha())

    matrix_string = ""

    # Add key characters without duplicates
    for char in key:
        if char not in matrix_string:
            matrix_string += char

    # Add remaining alphabet characters
    # J is excluded because I and J are combined
    alphabet = "ABCDEFGHIKLMNOPQRSTUVWXYZ"

    for char in alphabet:
        if char not in matrix_string:
            matrix_string += char

    # Create 5 x 5 matrix
    matrix = []

    for i in range(0, 25, 5):
        matrix.append(list(matrix_string[i:i + 5]))

    return matrix


# Display the matrix
def display_matrix(matrix):

    print("\nKey Matrix:")

    for row in matrix:
        print(" ".join(row))


# Prepare plaintext
def prepare_text(text):

    text = text.upper()

    # Replace J with I
    text = text.replace("J", "I")

    # Keep only alphabets
    text = "".join(char for char in text if char.isalpha())

    result = ""

    i = 0

    while i < len(text):

        first = text[i]

        # Check if another character exists
        if i + 1 < len(text):

            second = text[i + 1]

            # If both characters are same
            if first == second:

                result += first + "X"

                # Move only one position
                i += 1

            else:

                result += first + second

                # Move two positions
                i += 2

        else:

            # If one character is left, add X
            result += first + "X"

            i += 1

    return result


# Find row and column of a character
def find_position(matrix, char):

    for row in range(5):

        for col in range(5):

            if matrix[row][col] == char:

                return row, col


# Encryption
def encrypt(text, matrix):

    result = ""

    # Take two characters at a time
    for i in range(0, len(text), 2):

        first = text[i]
        second = text[i + 1]

        row1, col1 = find_position(matrix, first)
        row2, col2 = find_position(matrix, second)

        # Rule 1: Same row
        if row1 == row2:

            result += matrix[row1][(col1 + 1) % 5]
            result += matrix[row2][(col2 + 1) % 5]

        # Rule 2: Same column
        elif col1 == col2:

            result += matrix[(row1 + 1) % 5][col1]
            result += matrix[(row2 + 1) % 5][col2]

        # Rule 3: Rectangle
        else:

            # Keep rows, swap columns
            result += matrix[row1][col2]
            result += matrix[row2][col1]

    return result


# Decryption
def decrypt(text, matrix):

    result = ""

    # Take two characters at a time
    for i in range(0, len(text), 2):

        first = text[i]
        second = text[i + 1]

        row1, col1 = find_position(matrix, first)
        row2, col2 = find_position(matrix, second)

        # Rule 1: Same row
        if row1 == row2:

            result += matrix[row1][(col1 - 1) % 5]
            result += matrix[row2][(col2 - 1) % 5]

        # Rule 2: Same column
        elif col1 == col2:

            result += matrix[(row1 - 1) % 5][col1]
            result += matrix[(row2 - 1) % 5][col2]

        # Rule 3: Rectangle
        else:

            # Keep rows, swap columns
            result += matrix[row1][col2]
            result += matrix[row2][col1]

    return result


# ------------------------------------------------
# Main Program
# ------------------------------------------------

key = input("Enter keyword: ")

matrix = create_matrix(key)

display_matrix(matrix)


while True:

    print("\n===== PLAYFAIR CIPHER =====")

    print("1. Encrypt")
    print("2. Decrypt")
    print("3. Exit")

    choice = input("Enter your choice: ")

    # Encryption
    if choice == "1":

        plaintext = input("Enter plaintext: ")

        prepared = prepare_text(plaintext)

        print("Prepared text:", prepared)

        ciphertext = encrypt(prepared, matrix)

        print("Encrypted text:", ciphertext)


    # Decryption
    elif choice == "2":

        ciphertext = input("Enter ciphertext: ")

        plaintext = decrypt(ciphertext, matrix)

        print("Decrypted text:", plaintext)


    # Exit
    elif choice == "3":

        print("Program ended.")

        break


    else:

        print("Invalid choice!")"""