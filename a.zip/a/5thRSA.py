
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP

# Generate a 2048-bit RSA public and private key pair
key = RSA.generate(2048)

# Extract the public key and private key
public_key = key.publickey()
private_key = key

# Accept plaintext from the user
text = input("Enter plaintext: ")
data = text.encode()

# Create RSA encryption object using the public key and OAEP
encryptor = PKCS1_OAEP.new(public_key)

# Encrypt the plaintext
encrypted = encryptor.encrypt(data)

# Display the keys, plaintext and ciphertext
print("\nPublic Key:")
print(public_key.export_key().decode())

print("\nPrivate Key:")
print(private_key.export_key().decode())

print("\nPlaintext:", text)
print("Encrypted Ciphertext (Hexadecimal):", encrypted.hex())

# Create RSA decryption object using the private key and OAEP
decryptor = PKCS1_OAEP.new(private_key)

# Decrypt the ciphertext
decrypted = decryptor.decrypt(encrypted)

# Convert decrypted bytes back to text
recovered = decrypted.decode()

# Display recovered plaintext and verify it
print("Decrypted Plaintext:", recovered)
print("Verified:", recovered == text)













'''
RSA is an asymmetric-key encryption algorithm. It uses two different keys.
- Public key: Used to encrypt the message.
- Private key: Used to decrypt the message.
- 2048 bits: The required RSA key size for this experiment.
- OAEP: Padding that makes RSA encryption more secure.

'''
