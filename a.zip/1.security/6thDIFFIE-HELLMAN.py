# Primitive Root => g

def is_primitive(p,g):
    # check if p is primitive root of g
    # generate the mod values of g^k mod p
    # check if set length==p-1
    # if it generates all values from 1 to p-1,it is primitive Root
    set_len=set()
    for k in range(1,p):
        set_len.add(pow(g,k,p))

    return len(set_len)==p-1


# Diffie-Hellman Key Exchange

# Accept public values
p = int(input("Enter prime number (p): "))
g = int(input("Enter primitive root (g): "))

# Accept private keys of Alice and Bob
a = int(input("Enter Alice's private key: "))
b = int(input("Enter Bob's private key: "))

# Calculate public keys using modular exponentiation
A = pow(g, a, p)
B = pow(g, b, p)

# Exchange public keys and calculate shared secret keys
key_Alice = pow(B, a, p)
key_Bob = pow(A, b, p)

# Display the values
print("Prime Number:", p)
print("Primitive Root:", g)
print("Alice's Private Key:", a)
print("Bob's Private Key:", b)
print("Alice's Public Key:", A)
print("Bob's Public Key:", B)
print("Shared Key of Alice:", key_Alice)
print("Shared Key of Bob:", key_Bob)

# Verify that both shared keys are equal
if key_Alice == key_Bob:
    print("Shared keys are identical")
else:
    print("Shared keys are not identical")




'''
# Diffie-Hellman for Alice, Bob and Charlie

p = 23
g = 5

# Private keys
private = {"Alice": 6, "Bob": 15, "Charlie": 7}

# Generate public keys
public = {name: pow(g, key, p)
          for name, key in private.items()}

print("Public keys:", public)

# Calculate the shared key for every pair
users = list(private)

for i in range(len(users)):
    for j in range(i + 1, len(users)):
        x, y = users[i], users[j]

        key1 = pow(public[y], private[x], p)
        key2 = pow(public[x], private[y], p)

        print(x, "and", y, ":", key1)
        print("Verified:", key1 == key2)
'''



'''
Diffie–Hellman allows two people, Alice and Bob,
 to create the same secret key without directly sending that secret key to each other.

They agree on two public values:
- \(p\): a prime number.
- \(g\): a primitive root.


Each person chooses a private key. They calculate a public key, 
exchange their public keys, and then independently calculate 
the same shared secret.

\[
A=g^a\bmod p
\]

\[
B=g^b\bmod p
\]

\[
K_A=B^a\bmod p
\qquad
K_B=A^b\bmod p
\]
'''