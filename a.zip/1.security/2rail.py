"""
A transposition cipher changes the positions of letters without changing the letters themselves.

Your experiment has two transformations:
- Row Major: Fill the matrix column-wise, 
then read it row-wise.
- Column Major: Fill the matrix row-wise, 
then read it column-wise.
We use X as padding when the plaintext 
length is not a multiple of the number of columns.

For example, plaintext HELLOWORLD with 4 
columns needs 2 padding characters to fill the matrix.


Row Major Transformation
Fill column-wise, read row-wise.

The important point is that the filling direction and reading direction are different for the
 two transformations.


 
from math import ceil


def prepare_text(text, cols):
    # Remove spaces and convert to uppercase
    text = "".join(text.upper().split())

    # Add X until the matrix can be filled completely
    rows = ceil(len(text) / cols)
    text += "X" * (rows * cols - len(text))

    return text, rows


def show_matrix(matrix):
    for row in matrix:
        print(" ".join(row))


# Row Major: fill column-wise, read row-wise
def row_major_encrypt(text, cols):
    text, rows = prepare_text(text, cols)
    matrix = [[""] * cols for _ in range(rows)]

    index = 0

    # Fill the matrix column by column
    for c in range(cols):
        for r in range(rows):
            matrix[r][c] = text[index]
            index += 1

    print("\nRow Major Encryption Matrix:")
    show_matrix(matrix)

    # Read the matrix row by row
    ciphertext = "".join("".join(row) for row in matrix)
    return ciphertext, rows


def row_major_decrypt(ciphertext, rows, cols):
    matrix = [
        list(ciphertext[i * cols:(i + 1) * cols])
        for i in range(rows)
    ]

    # Reverse the process: read column by column
    plaintext = ""
    for c in range(cols):
        for r in range(rows):
            plaintext += matrix[r][c]

    return plaintext.rstrip("X")


# Column Major: fill row-wise, read column-wise
def column_major_encrypt(text, cols):
    text, rows = prepare_text(text, cols)

    # Fill the matrix row by row
    matrix = [
        list(text[i * cols:(i + 1) * cols])
        for i in range(rows)
    ]

    print("\nColumn Major Encryption Matrix:")
    show_matrix(matrix)

    # Read the matrix column by column
    ciphertext = ""
    for c in range(cols):
        for r in range(rows):
            ciphertext += matrix[r][c]

    return ciphertext, rows


def column_major_decrypt(ciphertext, rows, cols):
    matrix = [[""] * cols for _ in range(rows)]
    index = 0

    # Reconstruct the matrix column by column
    for c in range(cols):
        for r in range(rows):
            matrix[r][c] = ciphertext[index]
            index += 1

    # Read row by row to recover the padded plaintext
    plaintext = "".join("".join(row) for row in matrix)
    return plaintext.rstrip("X")


# Main program
plaintext = input("Enter plaintext: ")
cols = int(input("Enter number of columns: "))

if cols <= 0:
    print("Number of columns must be positive.")
elif not plaintext or not "".join(plaintext.split()):
    print("Plaintext cannot be empty.")
else:
    # Row Major transformation
    row_cipher, rows = row_major_encrypt(plaintext, cols)
    print("Row Major Ciphertext:", row_cipher)
    print("Row Major Decrypted Plaintext:",
          row_major_decrypt(row_cipher, rows, cols))

    # Column Major transformation
    col_cipher, rows = column_major_encrypt(plaintext, cols)
    print("Column Major Ciphertext:", col_cipher)
    print("Column Major Decrypted Plaintext:",
          column_major_decrypt(col_cipher, rows, cols))


"""