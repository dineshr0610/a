
import hashlib
import json
import os


# Function to generate MD5 digest of text
def md5(text):
    return hashlib.md5(text.encode()).hexdigest()


# Function to calculate MD5 checksum of a file
def file_md5(path):
    h = hashlib.md5()

    # Read file in binary mode to preserve its exact bytes
    with open(path, "rb") as f:
        for data in iter(lambda: f.read(4096), b""):
            h.update(data)

    return h.hexdigest()


# Main menu
while True:
    print("\n1. Generate MD5 Message Digest")
    print("2. Verify Message Integrity")
    print("3. Avalanche Effect")
    print("4. MD5 Checksum of a Text File")
    print("5. Compare MD5, SHA-1 and SHA-256")
    print("6. File Integrity Monitoring (JSON)")
    print("7. Exit")

    ch = input("Enter choice: ")

    # Option 1: Generate MD5 digest
    if ch == '1':
        text = input("Enter message: ")
        print("Message:", text)
        print("MD5:", md5(text))

    # Option 2: Verify message integrity
    elif ch == '2':
        text = input("Enter message: ")
        old_hash = input("Enter saved MD5 digest: ").strip().lower()

        # Recalculate hash and compare with the supplied digest
        if md5(text) == old_hash:
            print("Message Matches")
        else:
            print("Message Does Not Match")

    # Option 3: Demonstrate Avalanche Effect
    elif ch == '3':
        a = input("Enter original message: ")
        b = input("Enter modified message: ")

        print("Original MD5:", md5(a))
        print("Modified MD5:", md5(b))

    # Option 4: Calculate file checksum
    elif ch == '4':
        path = input("Enter file path: ")

        try:
            print("MD5 Checksum:", file_md5(path))
        except OSError as e:
            print("File error:", e)

    # Option 5: Compare three hash algorithms
    elif ch == '5':
        text = input("Enter message: ")
        data = text.encode()

        print("MD5:   ", hashlib.md5(data).hexdigest())
        print("SHA-1: ", hashlib.sha1(data).hexdigest())
        print("SHA-256:", hashlib.sha256(data).hexdigest())

    # Option 6: Monitor files using a JSON record
    elif ch == '6':
        folder = input("Enter folder path to monitor: ")
        record = "checksums.json"

        if not os.path.isdir(folder):
            print("Invalid folder path")
            continue

        # Load previously saved checksums
        record_path = os.path.join(folder, record)
        try:
            with open(record_path, "r") as f:
                old = json.load(f)
        except FileNotFoundError:
            old = {}
        except (json.JSONDecodeError, OSError) as e:
            print("Cannot read checksum record:", e)
            continue

        # Calculate checksums of current files in the folder
        current = {}
        for name in os.listdir(folder):
            path = os.path.join(folder, name)

            # Skip subfolders and the checksum record itself
            if name == record or not os.path.isfile(path):
                continue

            try:
                current[name] = file_md5(path)
            except OSError as e:
                print("Cannot read", name, ":", e)

        # Report new, modified and unchanged files
        for name, digest in current.items():
            if name not in old:
                print(name, "- New File")
            elif old[name] == digest:
                print(name, "- Not Modified")
            else:
                print(name, "- Modified")

        # Report files present in the old record but now missing
        for name in old:
            if name not in current:
                print(name, "- Missing File")

        # Save the latest checksums for the next run
        try:
            with open(record_path, "w") as f:
                json.dump(current, f, indent=4)
            print("Checksum record updated")
        except OSError as e:
            print("Cannot update record:", e)

    # Option 7: Exit
    elif ch == '7':
        print("Program ended")
        break

    else:
        print("Invalid choice")



"""
MD5 (Message Digest Algorithm 5) converts a message of any length into a fixed-length hash value.

MD5 produces a 128-bit (16-byte) digest, represented by 32 
hexadecimal characters.

It is a one-way hash function, not an encryption algorithm.

A small change in the message usually produces a 
very different digest. This is called the Avalanche Effect.

MD5 is not secure enough for modern security-sensitive 
applications, but it is suitable for learning this laboratory experiment.



"""