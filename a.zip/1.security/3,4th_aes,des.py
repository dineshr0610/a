
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad

# Accept plaintext and 16-byte secret key
text = input("Enter plaintext: ")
key = input("Enter 16-byte secret key: ").encode()

# Check that the key is exactly 16 bytes (AES-128)
if len(key) != 16:
    print("Error: Key must be exactly 16 bytes")
else:
    # Convert plaintext into bytes
    data = text.encode()

    # Create AES cipher using ECB mode
    cipher = AES.new(key, AES.MODE_ECB)

    # Add padding so data length is a multiple of 16 bytes
    padded = pad(data, AES.block_size)

    # Encrypt the padded plaintext
    encrypted = cipher.encrypt(padded)

    # Display ciphertext in hexadecimal format
    print("Plaintext:", text)
    print("Secret Key:", key.decode())
    print("Encrypted Ciphertext:", encrypted.hex())

    # Decrypt the ciphertext using the same key
    cipher2 = AES.new(key, AES.MODE_ECB)
    decrypted = unpad(cipher2.decrypt(encrypted), AES.block_size)

    # Convert decrypted bytes back into text
    recovered = decrypted.decode()
    print("Decrypted Plaintext:", recovered)

    # Verify that the original message was recovered
    print("Verified:", recovered == text)


'''
AES (Advanced Encryption Standard) is a symmetric-key encryption algorithm. It uses the same secret key to encrypt and decrypt a message.
Plaintext

AES supports keys of 128, 192, or 256 bits.

AES uses a fixed block size of 128 bits (16 bytes).

Your experiment uses AES-128 with ECB mode.

Padding is needed when the plaintext length is not a multiple of 16 bytes.

The ciphertext is displayed in hexadecimal format.


'''




from Crypto.Cipher import DES
from Crypto.Util.Padding import pad, unpad

# Get plaintext and 8-byte secret key
text = input("Enter plaintext: ")
key = input("Enter 8-byte secret key: ").encode()

# DES requires an 8-byte key
if len(key) != 8:
    print("Error: Key must be exactly 8 bytes")
else:
    # Convert plaintext into bytes
    data = text.encode()

    # Create DES cipher using ECB mode
    cipher = DES.new(key, DES.MODE_ECB)

    # Add padding to make the data a multiple of 8 bytes
    padded = pad(data, DES.block_size)

    # Encrypt the plaintext
    encrypted = cipher.encrypt(padded)

    # Display the ciphertext in hexadecimal
    print("Plaintext:", text)
    print("Secret Key:", key.decode())
    print("Encrypted Ciphertext:", encrypted.hex())

    # Decrypt using the same secret key
    cipher2 = DES.new(key, DES.MODE_ECB)
    decrypted = unpad(cipher2.decrypt(encrypted), DES.block_size)

    # Convert decrypted bytes back into text
    recovered = decrypted.decode()

    # Display and verify the recovered plaintext
    print("Decrypted Plaintext:", recovered)
    print("Verified:", recovered == text)


'''
DES (Data Encryption Standard) is a symmetric-key encryption algorithm.
- Symmetric key: The same key is used for encryption and decryption.

- Block size: 64 bits = 8 bytes.

- Key size: DES uses an effective 56-bit key, 
represented by an 8-byte ke


'''


