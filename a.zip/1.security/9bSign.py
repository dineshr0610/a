
from Crypto.PublicKey import RSA
from Crypto.Signature import pkcs1_15
from Crypto.Hash import SHA256

# 1. Alice generates her RSA key pair
alice_key = RSA.generate(2048)
private_key = alice_key
public_key = alice_key.publickey()

print("1. Alice generated RSA keys.")

# 2. Alice creates a message
message = input("Alice, enter message: ")
print("2. Original message:", message)

# 3. Alice hashes and signs the message
digest = SHA256.new(message.encode())
signature = pkcs1_15.new(private_key).sign(digest)

print("3. SHA-256 Digest:", digest.hexdigest())
print("4. Alice signed the message.")

# 4. Alice sends the message and signature to Bob
received_message = message
received_signature = signature
print("5. Message and signature sent to Bob.")

# 5. Bob verifies the received message
try:
    digest_received = SHA256.new(received_message.encode())
    pkcs1_15.new(public_key).verify(
        digest_received, received_signature
    )
    print("6. Bob: Signature VALID.")
except (ValueError, TypeError):
    print("6. Bob: Signature INVALID.")

# 6. Someone modifies the received message
modified_message = received_message + " MODIFIED"
print("\nModified message:", modified_message)

try:
    digest_modified = SHA256.new(modified_message.encode())
    pkcs1_15.new(public_key).verify(
        digest_modified, received_signature
    )
    print("Tampered message: Signature VALID.")
except (ValueError, TypeError):
    print("Tampered message: Signature INVALID.")
    print("Final Status: Message was altered.")
