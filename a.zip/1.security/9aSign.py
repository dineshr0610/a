

'''from Crypto.PublicKey import RSA
from Crypto.Signature import pkcs1_15
from Crypto.Hash import SHA256

# Generate keys
key = RSA.generate(2048)
public_key = key.publickey()
private_key = key

# Create a message digest
digest = SHA256.new(message.encode())

# Sign using the private key
signature = pkcs1_15.new(private_key).sign(digest)

# Verify using the public key
pkcs1_15.new(public_key).verify(digest, signature)'''



from Crypto.PublicKey import RSA
from Crypto.Signature import pkcs1_15
from Crypto.Hash import SHA256
import os

PRIVATE_FILE = "private.pem"
PUBLIC_FILE = "public.pem"


# Option 1: Generate and save RSA keys
def generate_keys():
    key = RSA.generate(2048)

    with open(PRIVATE_FILE, "wb") as f:
        f.write(key.export_key())

    with open(PUBLIC_FILE, "wb") as f:
        f.write(key.publickey().export_key())

    print("Keys generated and saved successfully.")
    print("\nPublic Key:")
    print(key.publickey().export_key().decode())

    print("\nPrivate Key:")
    print(key.export_key().decode())


# Option 2: Sign a message
def sign_message():
    if not os.path.exists(PRIVATE_FILE):
        print("Generate keys first.")
        return

    message = input("Enter message: ")

    with open(PRIVATE_FILE, "rb") as f:
        private_key = RSA.import_key(f.read())

    # Calculate SHA-256 digest
    digest = SHA256.new(message.encode())

    # Sign using the private key
    signature = pkcs1_15.new(private_key).sign(digest)

    print("Original Message:", message)
    print("Message Digest:", digest.hexdigest())
    print("Digital Signature:", signature.hex())


# Option 3: Verify a signature
def verify_signature():
    if not os.path.exists(PUBLIC_FILE):
        print("Generate keys first.")
        return

    message = input("Enter original message: ")
    signature_hex = input("Enter signature in hexadecimal: ")

    try:
        with open(PUBLIC_FILE, "rb") as f:
            public_key = RSA.import_key(f.read())

        signature = bytes.fromhex(signature_hex)
        digest = SHA256.new(message.encode())

        # Verify using the public key
        pkcs1_15.new(public_key).verify(digest, signature)
        print("Signature is VALID.")

    except (ValueError, TypeError):
        print("Signature is INVALID.")


# Option 4: Demonstrate message tampering
def demonstrate_tampering():
    if not os.path.exists(PRIVATE_FILE):
        print("Generate keys first.")
        return

    with open(PRIVATE_FILE, "rb") as f:
        private_key = RSA.import_key(f.read())

    with open(PUBLIC_FILE, "rb") as f:
        public_key = RSA.import_key(f.read())

    message = input("Enter message: ")

    # Sign the original message
    digest = SHA256.new(message.encode())
    signature = pkcs1_15.new(private_key).sign(digest)

    # Modify the message
    modified = message + " MODIFIED"

    print("Original Message:", message)
    print("Modified Message:", modified)

    try:
        new_digest = SHA256.new(modified.encode())
        pkcs1_15.new(public_key).verify(new_digest, signature)
        print("Signature is VALID.")
    except (ValueError, TypeError):
        print("Verification FAILED: Message was altered.")


# Option 5: Exit
def exit_program():
    print("Program ended.")


# Main menu
while True:
    print("\n=========== DIGITAL SIGNATURE SYSTEM ===========")
    print("1. Generate RSA Public and Private Keys")
    print("2. Digitally Sign a Message")
    print("3. Verify a Digital Signature")
    print("4. Demonstrate Message Tampering")
    print("5. Exit")
    print("================================================")

    choice = input("Enter your choice: ")

    if choice == "1":
        generate_keys()
    elif choice == "2":
        sign_message()
    elif choice == "3":
        verify_signature()
    elif choice == "4":
        demonstrate_tampering()
    elif choice == "5":
        exit_program()
        break
    else:
        print("Invalid choice. Enter 1 to 5.")



'''
A digital signature helps a receiver verify:
- Integrity: The message has not been changed.
- Authentication: The signature verifies 
using the sender's public key.
- Non-repudiation: The signature provides 
evidence that the sender signed the message.
'''