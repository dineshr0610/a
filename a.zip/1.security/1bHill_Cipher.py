from CryptoC import HillCipher

key = [[2, 3],
       [1, 4]]

cipher = HillCipher(key)

plaintext = "HELLO"

encrypted = cipher.encrypt(plaintext)
print("Encrypted:", encrypted)

decrypted = cipher.decrypt(encrypted)
print("Decrypted:", decrypted)


""" def mod_inverse(a, m):
    for x in range(1, m):
        if (a * x) % m == 1:
            return x
    return None


def matrix_inverse(key):
    a = key[0][0]
    b = key[0][1]
    c = key[1][0]
    d = key[1][1]

    # Calculate determinant
    determinant = (a * d - b * c) % 26

    # Find inverse of determinant
    det_inverse = mod_inverse(determinant, 26)

    if det_inverse is None:
        return None

    # Inverse matrix
    inverse = [
        [(d * det_inverse) % 26,
         (-b * det_inverse) % 26],

        [(-c * det_inverse) % 26,
         (a * det_inverse) % 26]
    ]

    return inverse


def encrypt(plaintext, key):

    plaintext = plaintext.upper()
    plaintext = "".join(c for c in plaintext if c.isalpha())

    # Add X if length is odd
    if len(plaintext) % 2 != 0:
        plaintext += "X"

    result = ""

    for i in range(0, len(plaintext), 2):

        x1 = ord(plaintext[i]) - ord('A')
        x2 = ord(plaintext[i + 1]) - ord('A')

        # Matrix multiplication
        y1 = (key[0][0] * x1 + key[0][1] * x2) % 26
        y2 = (key[1][0] * x1 + key[1][1] * x2) % 26

        result += chr(y1 + ord('A'))
        result += chr(y2 + ord('A'))

    return result


def decrypt(ciphertext, inverse_key):

    result = ""

    for i in range(0, len(ciphertext), 2):

        x1 = ord(ciphertext[i]) - ord('A')
        x2 = ord(ciphertext[i + 1]) - ord('A')

        # Matrix multiplication with inverse key
        y1 = (
            inverse_key[0][0] * x1 +
            inverse_key[0][1] * x2
        ) % 26

        y2 = (
            inverse_key[1][0] * x1 +
            inverse_key[1][1] * x2
        ) % 26

        result += chr(y1 + ord('A'))
        result += chr(y2 + ord('A'))

    return result


# ---------------- MAIN PROGRAM ----------------

print("===== HILL CIPHER =====")

print("\nEnter 2 x 2 key matrix:")

a = int(input("Enter a: "))
b = int(input("Enter b: "))
c = int(input("Enter c: "))
d = int(input("Enter d: "))

key = [
    [a, b],
    [c, d]
]

# Find inverse key
inverse_key = matrix_inverse(key)

if inverse_key is None:

    print("\nInvalid key matrix!")
    print("The matrix is not invertible modulo 26.")

else:

    print("\nKey Matrix:")
    print(key)

    print("\nInverse Key Matrix:")
    print(inverse_key)

    plaintext = input("\nEnter plaintext: ")

    ciphertext = encrypt(plaintext, key)

    print("Encrypted:", ciphertext)

    decrypted = decrypt(ciphertext, inverse_key)

    print("Decrypted:", decrypted) """



"""
III. Hill Cipher
4. Understand the idea
Hill cipher converts letters into numbers and encrypts them using matrix multiplication.

We use:
- A = 0, B = 1, ..., Z = 25
- A \(2 \times 2\) key matrix
- Modulo 26 arithmetic
Suppose the key matrix is:
\[
K=\begin{bmatrix}3&3\\2&5\end{bmatrix}
\]

For the plaintext pair HI:
\[
H=7,\quad I=8
\]

Represent the pair as a column vector:
\[
P=\begin{bmatrix}7\\8\end{bmatrix}
\]

Multiply the key matrix by the plaintext vector:
\[
C=KP\bmod 26
\]

\[
C=
\begin{bmatrix}
3&3\\2&5
\end{bmatrix}
\begin{bmatrix}7\\8\end{bmatrix}
\bmod 26
=
\begin{bmatrix}45\\54\end{bmatrix}
\bmod 26
=
\begin{bmatrix}19\\2\end{bmatrix}
\]

Therefore, \(19=T\) and \(2=C\), so HI encrypts to TC.
Why must the key matrix be invertible?
Encryption uses the key matrix \(K\). Decryption needs its inverse \(K^{-1}\):
\[
P=K^{-1}C\bmod 26
\]

For a \(2 \times 2\) matrix, the determinant is:
\[
\det(K)=ad-bc
\]

The matrix is valid only if its determinant has a modular inverse modulo 26. In other words:
\[
\gcd(\det(K),26)=1
\]

If this condition is not met, the key cannot uniquely decrypt every valid plaintext pair.




from math import gcd


def inverse_matrix(key):
    a, b = key[0]
    c, d = key[1]

    # Calculate determinant modulo 26
    det = (a * d - b * c) % 26

    # The determinant must have an inverse modulo 26
    if gcd(det, 26) != 1:
        raise ValueError("Invalid key matrix: determinant has no inverse modulo 26")

    # Find the modular inverse of the determinant
    inv_det = pow(det, -1, 26)

    # Inverse of a 2 x 2 matrix modulo 26
    return [
        [(d * inv_det) % 26, (-b * inv_det) % 26],
        [(-c * inv_det) % 26, (a * inv_det) % 26]
    ]


def process_text(text, key):
    # Keep letters only and convert to uppercase
    text = "".join(ch for ch in text.upper() if ch.isalpha())

    # Add X if the number of letters is odd
    if len(text) % 2 != 0:
        text += "X"

    result = ""

    # Process two letters at a time
    for i in range(0, len(text), 2):
        x = ord(text[i]) - ord("A")
        y = ord(text[i + 1]) - ord("A")

        # Matrix multiplication modulo 26
        p = (key[0][0] * x + key[0][1] * y) % 26
        q = (key[1][0] * x + key[1][1] * y) % 26

        result += chr(p + ord("A"))
        result += chr(q + ord("A"))

    return result


# Main program
print("Enter the 2 x 2 key matrix:")
a = int(input("Enter a: "))
b = int(input("Enter b: "))
c = int(input("Enter c: "))
d = int(input("Enter d: "))

key = [[a, b], [c, d]]

try:
    inv_key = inverse_matrix(key)

    plaintext = input("Enter plaintext: ")

    ciphertext = process_text(plaintext, key)
    decrypted = process_text(ciphertext, inv_key)

    print("Key Matrix:", key)
    print("Inverse Matrix:", inv_key)
    print("Plaintext:", plaintext.upper())
    print("Encrypted Ciphertext:", ciphertext)
    print("Decrypted Text:", decrypted)

except ValueError as e:
    print(e)

"""