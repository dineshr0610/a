
import hashlib

# Function to generate SHA-1 message digest
def sha1(text):
    return hashlib.sha1(text.encode()).hexdigest()


# Repeat the menu until the user exits
while True:
    print("\n1. Generate SHA-1")
    print("2. Avalanche Effect")
    print("3. Compare Messages")
    print("4. SHA-1 Preprocessing")
    print("5. Exit")

    ch = input("Enter choice: ")

    # Option 1: Generate SHA-1 hash
    if ch == '1':
        text = input("Enter message: ")
        print("Message:", text)
        print("SHA-1:", sha1(text))

    # Option 2: Demonstrate Avalanche Effect
    elif ch == '2':
        text = input("Enter message: ")

        # Check whether the message is empty
        if not text:
            print("Message cannot be empty")
            continue

        # Change the last character of the message
        modified = text[:-1] + ('A' if text[-1] != 'A' else 'B')

        # Compare hashes before and after modification
        print("Original:", sha1(text))
        print("Modified:", sha1(modified))

    # Option 3: Compare two messages using their hashes
    elif ch == '3':
        a = input("Enter first message: ")
        b = input("Enter second message: ")

        print("Hash 1:", sha1(a))
        print("Hash 2:", sha1(b))

        # Check whether both hashes are equal
        print("Identical" if sha1(a) == sha1(b) else "Different")

    # Option 4: Demonstrate SHA-1 preprocessing
    elif ch == '4':
        text = input("Enter message: ")

        # Convert the input text into bytes
        data = text.encode()

        # Convert each byte into 8-bit binary
        bits = ''.join(format(byte, '08b') for byte in data)

        # Find the original message length in bits
        length = len(bits)

        # Step 1: Append a single '1' bit
        padded = bits + '1'

        # Step 2: Append zeros until length becomes 448 modulo 512
        # This leaves 64 bits for the original message length
        padded += '0' * ((448 - len(padded) % 512) % 512)

       # while len(padded) % 512 != 448:padded += '0'
    
        # Step 3: Convert original length into a 64-bit binary number
        padded += format(length, '064b')

        # Display the original binary and final padded message
        print("Original binary:", bits)
        print("Padded message:", padded)

        # Step 4: Divide the padded message into 512-bit blocks
        for i in range(0, len(padded), 512):
            print("Block:", padded[i:i+512])

        # Generate the actual SHA-1 digest using hashlib
        print("SHA-1:", sha1(text))

    # Option 5: Exit the program
    elif ch == '5':
        print("Program ended")
        break

    # Handle invalid menu choices
    else:
        print("Invalid choice")



"""
SHA-1 stands for Secure Hash Algorithm 1. 
It converts any input message into a fixed-length hash value 
called a message digest.

SHA-1 always produces a 160-bit (20-byte) digest, 
usually displayed as 40 hexadecimal characters.



It is a one-way process: you cannot normally recover 
the original message from its hash.



If even one character changes, the hash usually changes significantly. 
This is called the Avalanche Effect.

"""