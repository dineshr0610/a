def buildMatrix(key):
    key=key.upper()
    key=key.replace("J","I")

    characters="ABCDEFGHIKLMNOPQRSTUVWXYZ"

    res=key
    for char in characters:
        if char not in res:
            res+=char

    matrix=[['' for _ in range(5)] for _ in range(5)]
    k=0
    for r in range(5):
        for c in range(5):
            matrix[r][c]=res[k]
            k+=1

    return matrix

def preprocess(text):
    text=text.upper().replace("J","I")


    filler="X"
    i=0
    bigrams=[]
    while i<len(text):
        curr=text[i]
        if i+1<len(text):
            next=text[i+1]

            if next!=curr:
                bigrams.append(curr+next)
                i+=2
            else:
                bigrams.append(curr+filler)
                i+=1
        else:
            bigrams.append(curr+filler)
            i+=1
    print(bigrams)
    return bigrams

def findPos(char,matrix):
    for i in range(5):
        for j in range(5):
            if matrix[i][j]==char:
                return i,j

def encrypt(bigrams,matrix):
    ans=""
    for pair in bigrams:
        row1,col1=findPos(pair[0],matrix)
        row2,col2=findPos(pair[1],matrix)

        if row1==row2:
            ans+=matrix[row1][(col1+1)%5]
            ans+=matrix[row1][(col2+1)%5]
        elif col1==col2:
            ans+=matrix[(row1+1)%5][col1]
            ans+=matrix[(row2+1)%5][col1]
        else:
            ans+=matrix[row1][col2]
            ans+=matrix[row2][col1]
    print(ans)
    return ans

def decrypt(ciphertext,matrix):
    bigrams=[]
    for i in range(0,len(ciphertext),2):
        bigrams.append(ciphertext[i:i+2])
    
    ans=""
    for pair in bigrams:
        row1,col1=findPos(pair[0],matrix)
        row2,col2=findPos(pair[1],matrix)

        if row1==row2:
            ans+=matrix[row1][(col1-1)%5]
            ans+=matrix[row1][(col2-1)%5]
        elif col1==col2:
            ans+=matrix[(row1-1)%5][col1]
            ans+=matrix[(row2-1)%5][col1]
        else:
            ans+=matrix[row1][col2]
            ans+=matrix[row2][col1]
    print(ans)
    return ans

matrix=buildMatrix("MONARCHY")
bigrams=preprocess("HIIHELLO")
print(bigrams)
encrypted=encrypt(bigrams,matrix)
decypted=decrypt(encrypted,matrix)