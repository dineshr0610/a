import hashlib

def hash_function(message):
    # convert into bytes as SHA expects Bytes
    # convert hash into hexadecimal

    return hashlib.sha1(message.encode()).hexdigest()

def generate_hash(text):

    hash=hash_function(text)
    print("Original Text:",text)
    print("Hashed Value:",hash)


# Avalanche Effect
# A small change in the input should 
# produce a large and unpredictable change in the hash output.
def avalanche():
    text=input("Enter the Text:")
    position=int(input("Enter the Position of the char to be changed:"))
    character=input("Enter the Character:")
    # 1 indexed
    # HELLO  with pos=3
    # HE till 1 which position-1
    # LO which position:
    modified_message=text[:position-1]+character+text[position:]

    original_hash=hash_function(text)
    modified_hash=hash_function(modified_message)
    print("Original Text:",text)
    print("Modified Text:",modified_message)
    print("Original Hash:",original_hash)
    print("Modified Hash:",modified_hash)

def preprocessing(text):
    # First Convert the text into Bytes
    # a->97,b->98
    # 08b -> represent the data in 8bit binary
    # Convert the Bytes into binary using format(byte,"08b")
    # binary is string
    binary=""
    for data in text.encode():
        binary+=format(data,"08b")

    # pad 1 and then pad until length%512=448
    padded=binary+"1"
    while len(padded)%512!=448:
        padded+="0"


    # add the length as 64 bit representation
    padded+=format(len(binary),"064b")
    print("Padded Message:",padded)
    print("Padded Length:",len(padded))
    for i in range(0,len(padded),512):
        block=padded[i:i+512]
        print("Block:",i//512+1)

    hashed=hash_function(text)
    print("Hash Value:",hashed)
preprocessing("HI HELOOW HI WEJAJSNJSNASDSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSF")