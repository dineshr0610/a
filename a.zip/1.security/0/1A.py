
def encrypt(word,key):
    ans=""
    print(word)
    for char in word:
        currentAscii=ord(char)

        if currentAscii>=65 and currentAscii<=90:
            encry=(currentAscii-ord("A")+key)%26+ord("A")
            ans+=chr(encry)
        elif currentAscii>=97 and currentAscii<=122:
            encry=(currentAscii-ord("a")+key)%26+ord("a")
            ans+=chr(encry)
        else:
            ans+=char
    print(ans)
    return ans
def decrypt(word,key):
    ans=""
    for char in word:
        currentAscii=ord(char)

        if currentAscii>=65 and currentAscii<=90:
            decry=(currentAscii-ord("A")-key)%26+ord("A")
            ans+=chr(decry)
        elif currentAscii>=97 and currentAscii<=122:
            decry=(currentAscii-ord("a")-key)%26+ord("a")
            ans+=chr(decry)
        else:
            ans+=char
    print(ans)
    return ans

def brute_force(encryted):
    
    for key in range(1,26):
        ans=""
        print("Key:",key)
        for char in encryted:
                currentAscii=ord(char)
        
                if currentAscii>=65 and currentAscii<=90:
                    decry=(currentAscii-ord("A")-key)%26+ord("A")
                    ans+=chr(decry)
                elif currentAscii>=97 and currentAscii<=122:
                    decry=(currentAscii-ord("a")-key)%26+ord("a")
                    ans+=chr(decry)
                else:
                    ans+=char
        print(ans)
decrypt(encrypt("abc",3),3)

brute_force("def")

