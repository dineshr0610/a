from Crypto.PublicKey import RSA
from Crypto.Signature import pkcs1_15
from Crypto.Hash import SHA256

def verify_message_email(message,digital_signature,public_key):

    digest=SHA256.new(message.encode('utf-8'))

    try:
        verified=pkcs1_15.new(public_key).verify(digest,digital_signature)
        return True

    except (ValueError,TypeError):
        return False

def sign_message_email(message,private_key):
   

    digest=SHA256.new(message.encode("utf-8"))
    signature_data=pkcs1_15.new(private_key).sign(digest)

    print("Message:",message)
    print("Digest:",digest.hexdigest())

    return digest,signature_data

private_key=None
public_key=None
signature_data=None

#Digital Signature
# Used to Verify Message Authenticity () and Integrity


def generate_keys():
    global public_key,private_key
    key=RSA.generate(2048)
    private_key=key
    public_key=key.publickey()

    print("Key Pair Generated")



# SHA -> Used for verifying the integrity of the message
# Receiver calculates the SHA for message and compares with incoming SHA from sender 
# To Check if it is modified or not
def sign_message(message):
    global signature_data

    digest=SHA256.new(message.encode("utf-8"))
    signature_data=pkcs1_15.new(private_key).sign(digest)

    print("Message:",message)
    print("Digest:",digest.hexdigest())

    return signature_data

# Receiver Receives the digital signature and message
# verifies the digital signature and message using the public key of the sender

def verify_message(message,digital_signature):

    digest=SHA256.new(message.encode('utf-8'))

    try:
        verified=pkcs1_15.new(public_key).verify(digest,digital_signature)
        return True

    except (ValueError,TypeError):
        return False


def verify_option():

    message=input("Enter the received message:")
    print("Received Signature:",signature_data)
    if verify_message(message,signature_data):
        print("Success Verification")
    else:
        print("Failed")


# Sender Sends Message+Signature
# Receiver Receives the modified message + Signature
def tampering_demo():
    message=input("Enter the Message:")

    signature_data=sign_message(message)

    # Attacker modifies the message
    modified_message=message+"tampered"
    print("Message from sender:",message)
    print("Message received:",modified_message)
    if verify_message(modified_message,signature_data):
        print("Success")
    else:
        print("Failure")


def secure_email_demo():
    # Generate the keys
    key=RSA.generate(2048)
    alice_public_key=key.publickey()
    alice_private_key=key
    # Get the message
    message=input("Enter the message to be sent:")
    digest,digital_signature=sign_message_email(message,alice_private_key)
    print("Digest:",digest.hexdigest())
    print("Signature Data:",digital_signature)

    # Bob Receives
    print("Bob Receives the data")
    # Bob Verifies
    if verify_message_email(message,digital_signature,alice_public_key):
        print("Success")
    else:
        print("Failed")

    # Tamper the message
    tampered_message=message+"X"
    print("Tampered Message:",tampered_message)
    if verify_message_email(tampered_message,digital_signature,alice_public_key):
        print("Success After Tampering")
    else:
        print("Failed After Tampering")




while True:
    print("\n===== DIGITAL SIGNATURE MENU =====")
    print("1. Generate RSA Keys")
    print("2. Sign a Message")
    print("3. Verify a Received Message")
    print("4. Demonstrate Tampering")
    print("5. Secure Email Demo")

    choice = input("Enter your choice: ")

    if choice == "1":
        generate_keys()

    elif choice == "2":
        message = input("Enter the message to sign: ")
        sign_message(message)

    elif choice == "3":
        verify_option()

    elif choice == "4":
        tampering_demo()

    elif choice == "5":
        secure_email_demo()
    
    else:
        print("Invalid choice! Please select 1-5.")
