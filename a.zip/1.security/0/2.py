import math
# Row Major

# Encrpyt
# Fill the plain Text column Wise
# Read cipher as row wise

# Decrypt
# Fill cipher row wise
# Read plain as col wise

def row_encrypt(plain_text,cols):
    rows=math.ceil(len(plain_text)/cols)
    while len(plain_text)<rows*cols:
        plain_text+="X"

    matrix=[['' for _ in range(cols)] for _ in range(rows)]
    k=0
    
    for c in range(cols):
        for r in range(rows):
            matrix[r][c]=plain_text[k]
            k+=1
    cipher=""
    for r in range(rows):
        for c in range(cols):
            cipher+=matrix[r][c]
    print(cipher)
    return cipher,rows

def row_decrypt(cipher,rows,cols):
    matrix=[['' for _ in range(cols)] for _ in range(rows)]
    k=0
    for r in range(rows):
        for c in range(cols):
            matrix[r][c]=cipher[k]
            k+=1

    plain=""
    for c in range(cols):
        for r in range(rows):
            plain+=matrix[r][c]
    l=len(plain)-1
    while plain[l]=='X':
        l-=1
    print(plain[:l+1])

# plain_text=input("Enter the plain Text:")
# cols=int(input("Enter the No of Cols:"))

# cipher,rows=row_encrypt(plain_text,cols)
# row_decrypt(cipher,rows,cols)


# fill col wise
# read row wise
def row_major_encrypt(plain,cols):
    rows=math.ceil(len(plain)/cols)
    matrix=[['' for _ in range(cols)] for _ in range(rows)]
    while len(plain)<rows*cols:
        plain+="X"
    k=0
    for c in range(cols):
        for r in range(rows):
            matrix[r][c]=plain[k]
            k+=1

    cipher=""
    for r in range(rows):
        for c in range(cols):
            cipher+=matrix[r][c]
    print(cipher)
    return cipher

# fill row wise
# read col wise
def row_major_decrypt(cipher,cols):
    rows=math.ceil(len(cipher)/cols)
    matrix=[['' for _ in range(cols)] for _ in range(cols)]
    k=0
    for r in range(rows):
        for c in range(cols):
            matrix[r][c]=cipher[k]
            k+=1

    plain=""
    for c in range(cols):
        for r in range(rows):
            plain+=matrix[r][c]

    l=len(plain)-1
    while plain[l]=='X':
        l-=1
    print(plain[:l+1])

row_major_decrypt(row_major_encrypt("Hihello",3),3)

 