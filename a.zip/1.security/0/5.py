from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP

key=RSA.generate(2048)

public_key=key.publickey()
private_key=key

print("Public Key:",public_key.export_key().decode())
print("Private Key:",private_key.export_key().decode())

text=input("Enter the input:")

encryption=PKCS1_OAEP.new(public_key)
cipher=encryption.encrypt(text.encode())

print("Cipher:",cipher.hex())

decryption=PKCS1_OAEP.new(private_key)
plain=decryption.decrypt(cipher)

print("Plain:",plain.decode())