# from Crypto.Cipher import DES
# from Crypto.Util.Padding import pad,unpad

# # get input key
# # get plain text
# # convert key to bytes
# # add padding to plain text
# # encrypt
# # decrypt

# key=input("Enter the Input Key (8 Bytes):")
# if len(key)!=8:
#     print("Key Len Must Be 8 Bytes")
#     exit()

# plain_text=input("Enter the Plain Text:")
# key=key.encode()
# cipher=DES.new(key,DES.MODE_ECB)

# padded=pad(plain_text.encode(),DES.block_size)
# encryped=cipher.encrypt(padded)
# print("Encrpted: ",encryped.hex())
# print("Secret Key:",key.decode())

# dec=cipher.decrypt(encryped)
# recovered=unpad(dec,DES.block_size).decode()
# print(recovered)\


from Crypto.Cipher import DES
from Crypto.Util.Padding import pad,unpad

key=input("Enter the Key:")
key=key.encode()

inp=input("Enter the plain text:")

cipher=DES.new(key,DES.MODE_ECB)

print("Key:",key.decode())
#pad it
# encrypt it
padded=pad(inp.encode(),DES.block_size)
cipherText=cipher.encrypt(padded)

print("Cipher Text:",cipherText.hex())
plainText=cipher.decrypt(cipherText)
unpadded=unpad(plainText,DES.block_size).decode()

print("Plain:",unpadded)