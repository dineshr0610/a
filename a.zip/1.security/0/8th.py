# MD5
# Mainly for integrity of the file system
# Detect if the file is changed or not
import hashlib
import os
import json
# Generate MD5 for a text
def generate_md5(text):
    return hashlib.md5(text.encode("utf-8")).hexdigest()

def file_md5(file_path):
    md5=hashlib.md5()

    # open and read the file as binary
    # since md5 can operate only on bytes
    try:
        with open(file_path,"rb") as f:
            while True:
                data=f.read(4086)

                if not data:
                    break
                md5.update(data)
        # represents hash as Hexadecimal
        return md5.hexdigest()
    except FileNotFoundError:
        return None
    
# Choice 1

def generate_digest(text):
    digest=generate_md5(text)

    print("Message:",text)
    print("Digest:",digest)
    return digest

# Choice 2
# check if the current message digest matches with previous generated Digest

def verify_integrity():
    text=input("Enter the message:")
    digest=input("Enter the already generated digest:")

    calculated=generate_digest(text)

    print("Previous:",digest)
    print("After   :",calculated)

    if calculated.lower()==digest.lower():
        print("Success")
    else:
        print("Failure")

# generate the MD5 for nearly identical strings
def avalanche():    
    text1=input("Enter text1:")
    text2=input("Enter text2:")

    digest1=generate_md5(text1)
    digest2=generate_md5(text2)

    print("Digest 1:",digest1)
    print("Digest 2:",digest2)

# Choice 4

def generate_file_checksum():    
    filepath = input("\nEnter text file path: ")    
    checksum = file_md5(filepath)    
    if checksum is None:        
        print("\nFile not found.")    
    else:        
        print("\nMD5 Checksum:")        
        print(checksum)


def generate_file_checksum1(filepath):    
      
    checksum = file_md5(filepath)    
    if checksum is None:        
        print("\nFile not found.")    
    else:        
        print("\nMD5 Checksum:")        
        print(checksum)
    return checksum
# Choice 5
# generate hash for MD5 and SHA



# Load checksum json data from file
def load_checksum(file_path):
    if not os.path.exists(file_path):
        return {}

    try:
        
        with open(file_path,"r") as f:
            # json.load not loads
            # convert the json file into python object
            return json.load(f)

    except FileNotFoundError:
        return {}

def save_checksum(file_path,checksum):

    with open(file_path,"w") as f:
        # Convert the python dictionary to store into the json file
        json.dump(checksum,f,indent=4)


# Functions
# Function1:Load Checksum from the json file into python 
# Function2:Save the current processed checksum into json file

# File Integrity
# Check if File is Missing Or Modified Or Not Modified
# for missing -> check if file stored in json is there or not using os.path.exists
# for modified-> compare the current checksum with previous checksum 
# for new     -> go through all the files in current directory and check if it there in curr_checksum

def file_integrity():
    stored_checksum=load_checksum("checksum.json")
    currentChecksum={}
    if stored_checksum:
        for file_name,checksum in stored_checksum.items():

            if not os.path.exists(file_name):
                print("[File Missing] -> ",file_name)
                continue

            currentChecksum1=generate_file_checksum1(file_name)
            currentChecksum[file_name]=currentChecksum1
            if currentChecksum1==checksum:
                print("[Not Modified]->",file_name)
            else:
                print("[Modified]->",file_name)
    else:
        print("No Stored Files")

    for file in os.listdir("."):
        if file=="checksum.json":
            continue

        if not file.lower().endswith(".txt"):
            continue

        if file not in currentChecksum:
            checksum=generate_file_checksum1(file)

            currentChecksum[file]=checksum
            print("[New File]->",file)

    save_checksum("checksum.json",currentChecksum)
    print("Stored in Checksum.json")


def main():
    while True:
        print("\n" + "=" * 55)
        print("             MD5 DIGEST SYSTEM")
        print("=" * 55)

        print("1. Generate MD5 Message Digest")
        print("2. Verify Message Integrity")
        print("3. Demonstrate Avalanche Effect")
        print("4. Generate MD5 File Checksum")
        print("5. Compare MD5, SHA-1 and SHA-256")
        print("6. File Integrity Monitoring")
        print("7. Exit")

        choice = input("\nEnter your choice: ")

        if choice == "1":
            inp=input("Enter text:")
            generate_digest(inp)

        elif choice == "2":
            verify_integrity()

        elif choice == "3":
            avalanche()

        elif choice == "4":
            generate_file_checksum()


        elif choice == "6":
            file_integrity()

        elif choice == "7":
            print("\nProgram terminated.")
            break

        else:
            print("\nInvalid choice. Please enter 1-7.")


if __name__ == "__main__":
    main()