

# Primitive Root => g

def is_primitive(p,g):
    # check if p is primitive root of g
    # generate the mod values of g^k mod p
    # check if set length==p-1
    # if it generates all values from 1 to p-1,it is primitive Root
    set_len=set()
    for k in range(1,p):
        set_len.add(pow(g,k,p))

    return len(set_len)==p-1


g=int(input("Enter the Generator:"))
p=int(input("Enter the Mod P:"))
# Private Key (Get From User)
X_A=int(input("Enter the Private Key for Alice:"))
X_B=int(input("Enter the Private Key for Bob:"))

# Public Key
# Generator^Private Key

Y_A=pow(g,X_A,p)
Y_B=pow(g,X_B,p)

# Shared Key

K_A=pow(Y_B,X_A,p)
K_B=pow(Y_A,X_B,p)


# Display results
print("\n--- Diffie-Hellman Key Exchange ---")
print("Prime Number (p):", p)
print("Primitive Root (g):", g)
print("Alice's Private Key (X_A):", X_A)
print("Bob's Private Key (X_B):", X_B)
print("Alice's Public Key (Y_A):", Y_A)
print("Bob's Public Key (Y_B):", Y_B)
print("Shared Secret Key computed by Alice:", K_A)
print("Shared Secret Key computed by Bob:", K_B)


if K_A==K_B:
    print("Successful")
else:
    print("Unsuccessful")