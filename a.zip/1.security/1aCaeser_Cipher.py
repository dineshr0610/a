def caesar_cipher(text, shift, mode):
    result = ""
    count = 0

    vowels = "aeiouAEIOU"

    for char in text:

        # Check whether character is a letter
        if char.isalpha():

            # Decide whether to encrypt this character
            encrypt_char = False

            if mode == "normal":
                encrypt_char = True

            elif mode == "vowels":
                if char in vowels:
                    encrypt_char = True

            elif mode == "consonants":
                if char not in vowels:
                    encrypt_char = True

            # Encrypt the character
            if encrypt_char:
                base = ord('A') if char.isupper() else ord('a')

                result += chr(
                    (ord(char) - base + shift) % 26 + base
                )

                count += 1

            else:
                result += char

        else:
            # Keep numbers, spaces and symbols unchanged
            result += char

    return result, count


def decrypt(text, shift):
    result = ""

    for char in text:

        if char.isalpha():
            base = ord('A') if char.isupper() else ord('a')

            result += chr(
                (ord(char) - base - shift) % 26 + base
            )

        else:
            result += char

    return result


while True:

    print("\n===== CAESAR CIPHER =====")
    print("1. Normal Encryption")
    print("2. Encrypt Only Vowels")
    print("3. Encrypt Only Consonants")
    print("4. Encryption with Character Count")
    print("5. Decryption")
    print("6. Brute Force Attack")
    print("7. Exit")

    choice = input("Enter your choice: ")

    # 1. Normal Encryption
    if choice == "1":

        text = input("Enter plaintext: ")
        shift = int(input("Enter shift: "))

        encrypted, count = caesar_cipher(text, shift, "normal")

        print("Encrypted text:", encrypted)

    # 2. Encrypt only vowels
    elif choice == "2":

        text = input("Enter plaintext: ")
        shift = int(input("Enter shift: "))

        encrypted, count = caesar_cipher(text, shift, "vowels")

        print("Encrypted text:", encrypted)

    # 3. Encrypt only consonants
    elif choice == "3":

        text = input("Enter plaintext: ")
        shift = int(input("Enter shift: "))

        encrypted, count = caesar_cipher(text, shift, "consonants")

        print("Encrypted text:", encrypted)

    # 4. Encryption with character count
    elif choice == "4":

        text = input("Enter plaintext: ")
        shift = int(input("Enter shift: "))

        encrypted, count = caesar_cipher(text, shift, "normal")

        print("Encrypted text:", encrypted)
        print("Number of characters encrypted:", count)

    # 5. Decryption
    elif choice == "5":

        text = input("Enter ciphertext: ")
        shift = int(input("Enter shift: "))

        decrypted = decrypt(text, shift)

        print("Decrypted text:", decrypted)

    # 6. Brute Force Attack
    elif choice == "6":

        text = input("Enter ciphertext: ")

        print("\nPossible plaintexts:")

        for shift in range(1, 26):
            decrypted = decrypt(text, shift)
            print("Shift", shift, ":", decrypted)

    # 7. Exit
    elif choice == "7":

        print("Program ended.")
        break

    else:
        print("Invalid choice. Please try again.")




        """
 Caesar Cipher is a substitution cipher. 
 Each letter is shifted forward by a fixed 
 number of positions to encrypt it.

A → D, B → E, C → F, and so on.

When we reach the end of the alphabet, 
we wrap around. For example, X shifted by 3 
becomes A.

The formula is:
\[
E(x)=(x+k)\bmod 26
\]

\[
D(x)=(x-k)\bmod 26
\]

Here, \(x\) is the letter's position
 from 0 to 25, and \(k\) is the shift value.


  
def encrypt(text, shift):
    result = ""

    # Handle shift values greater than 26
    shift = shift % 26

    for char in text:
        if char.isalpha():
            # Select the ASCII base for uppercase or lowercase
            base = ord('A') if char.isupper() else ord('a')

            # Shift the letter and wrap around the alphabet
            result += chr((ord(char) - base + shift) % 26 + base)
        else:
            # Keep spaces, numbers and symbols unchanged
            result += char

    return result


def decrypt(text, shift):
    # Decryption shifts letters backward
    return encrypt(text, -shift)


# Main program
text = input("Enter text: ")
shift = int(input("Enter shift: "))

encrypted = encrypt(text, shift)
decrypted = decrypt(encrypted, shift)

print("Encrypted:", encrypted)
print("Decrypted:", decrypted)
      
        
        
        
 """