from CryptoC import Playfair, HillCipher

playfair = Playfair("KEYWORD")

encrypted = playfair.encrypt("HELLO")

print(encrypted)
decrypted = playfair.decrypt(encrypted)


"""# Playfair Cipher - Encryption and Decryption


# Create 5 x 5 key matrix
def create_matrix(key):

    key = key.upper()

    # Replace J with I
    key = key.replace("J", "I")

    # Remove spaces and non-alphabet characters
    key = "".join(char for char in key if char.isalpha())

    matrix_string = ""

    # Add key characters without duplicates
    for char in key:
        if char not in matrix_string:
            matrix_string += char

    # Add remaining alphabet characters
    # J is excluded because I and J are combined
    alphabet = "ABCDEFGHIKLMNOPQRSTUVWXYZ"

    for char in alphabet:
        if char not in matrix_string:
            matrix_string += char

    # Create 5 x 5 matrix
    matrix = []

    for i in range(0, 25, 5):
        matrix.append(list(matrix_string[i:i + 5]))

    return matrix


# Display the matrix
def display_matrix(matrix):

    print("\nKey Matrix:")

    for row in matrix:
        print(" ".join(row))


# Prepare plaintext
def prepare_text(text):

    text = text.upper()

    # Replace J with I
    text = text.replace("J", "I")

    # Keep only alphabets
    text = "".join(char for char in text if char.isalpha())

    result = ""

    i = 0

    while i < len(text):

        first = text[i]

        # Check if another character exists
        if i + 1 < len(text):

            second = text[i + 1]

            # If both characters are same
            if first == second:

                result += first + "X"

                # Move only one position
                i += 1

            else:

                result += first + second

                # Move two positions
                i += 2

        else:

            # If one character is left, add X
            result += first + "X"

            i += 1

    return result


# Find row and column of a character
def find_position(matrix, char):

    for row in range(5):

        for col in range(5):

            if matrix[row][col] == char:

                return row, col


# Encryption
def encrypt(text, matrix):

    result = ""

    # Take two characters at a time
    for i in range(0, len(text), 2):

        first = text[i]
        second = text[i + 1]

        row1, col1 = find_position(matrix, first)
        row2, col2 = find_position(matrix, second)

        # Rule 1: Same row
        if row1 == row2:

            result += matrix[row1][(col1 + 1) % 5]
            result += matrix[row2][(col2 + 1) % 5]

        # Rule 2: Same column
        elif col1 == col2:

            result += matrix[(row1 + 1) % 5][col1]
            result += matrix[(row2 + 1) % 5][col2]

        # Rule 3: Rectangle
        else:

            # Keep rows, swap columns
            result += matrix[row1][col2]
            result += matrix[row2][col1]

    return result


# Decryption
def decrypt(text, matrix):

    result = ""

    # Take two characters at a time
    for i in range(0, len(text), 2):

        first = text[i]
        second = text[i + 1]

        row1, col1 = find_position(matrix, first)
        row2, col2 = find_position(matrix, second)

        # Rule 1: Same row
        if row1 == row2:

            result += matrix[row1][(col1 - 1) % 5]
            result += matrix[row2][(col2 - 1) % 5]

        # Rule 2: Same column
        elif col1 == col2:

            result += matrix[(row1 - 1) % 5][col1]
            result += matrix[(row2 - 1) % 5][col2]

        # Rule 3: Rectangle
        else:

            # Keep rows, swap columns
            result += matrix[row1][col2]
            result += matrix[row2][col1]

    return result


# ------------------------------------------------
# Main Program
# ------------------------------------------------

key = input("Enter keyword: ")

matrix = create_matrix(key)

display_matrix(matrix)


while True:

    print("\n===== PLAYFAIR CIPHER =====")

    print("1. Encrypt")
    print("2. Decrypt")
    print("3. Exit")

    choice = input("Enter your choice: ")

    # Encryption
    if choice == "1":

        plaintext = input("Enter plaintext: ")

        prepared = prepare_text(plaintext)

        print("Prepared text:", prepared)

        ciphertext = encrypt(prepared, matrix)

        print("Encrypted text:", ciphertext)


    # Decryption
    elif choice == "2":

        ciphertext = input("Enter ciphertext: ")

        plaintext = decrypt(ciphertext, matrix)

        print("Decrypted text:", plaintext)


    # Exit
    elif choice == "3":

        print("Program ended.")

        break


    else:

        print("Invalid choice!")"""


"""
II. Playfair Cipher
1. Understand the idea
The Caesar cipher encrypts one letter at a time. Playfair encrypts two letters together, called a pair or digraph.

For example, the plaintext HELLO cannot be split directly into HE LL O, because LL repeats in the same pair and the final letter has no partner. We preprocess it first.
Step 1: Create the 5 × 5 key matrix
Suppose the keyword is MONARCHY.
- Remove repeated letters from the keyword.
- Add the remaining letters of the alphabet.
- Treat I and J as the same letter, so the matrix contains 25 letters.



Keyword: MONARCHY. I and J share one position.
Step 2: Preprocess the plaintext
The rules are:
- Convert letters to uppercase and replace J with I.
- Split the message into pairs.
- If a pair contains the same letter twice, insert X between them.
- If one letter remains at the end, append X.
Example:

HELLO → HE LX LO

The repeated LL is split by inserting X, and the resulting letters form valid pairs.
Step 3: Encrypt each pair
- Same row: Take the letter immediately to the right, wrapping around at the end.
- Same column: Take the letter immediately below, wrapping around at the bottom.
- Different row and column: Keep each letter's row and use the other letter's column (the rectangle rule).
Decryption reverses these rules: left for the same row, up for the same column, and the same rectangle rule for different rows and columns.


def create_matrix(keyword):
    # I and J share one position
    keyword = keyword.upper().replace("J", "I")
    alphabet = "ABCDEFGHIKLMNOPQRSTUVWXYZ"

    # Remove duplicate letters while preserving order
    letters = ""
    for ch in keyword + alphabet:
        if ch.isalpha() and ch in alphabet and ch not in letters:
            letters += ch

    # Arrange the 25 letters into a 5 x 5 matrix
    return [list(letters[i:i+5]) for i in range(0, 25, 5)]


def prepare_text(text):
    # Keep letters only, convert J to I
    text = "".join(ch for ch in text.upper() if ch.isalpha())
    text = text.replace("J", "I")

    pairs = []
    i = 0

    while i < len(text):
        a = text[i]

        if i + 1 >= len(text):
            # Add X if the final letter has no partner
            b = "X"
            i += 1
        elif text[i] == text[i + 1]:
            # Separate repeated letters in a pair
            b = "X"
            i += 1
        else:
            b = text[i + 1]
            i += 2

        pairs.append(a + b)

    return pairs


def find_position(matrix, ch):
    for r in range(5):
        for c in range(5):
            if matrix[r][c] == ch:
                return r, c


def playfair(text, matrix, encrypt=True):
    result = ""

    for pair in prepare_text(text):
        a, b = pair
        r1, c1 = find_position(matrix, a)
        r2, c2 = find_position(matrix, b)

        if r1 == r2:
            # Same row: right for encryption, left for decryption
            shift = 1 if encrypt else -1
            result += matrix[r1][(c1 + shift) % 5]
            result += matrix[r2][(c2 + shift) % 5]

        elif c1 == c2:
            # Same column: down for encryption, up for decryption
            shift = 1 if encrypt else -1
            result += matrix[(r1 + shift) % 5][c1]
            result += matrix[(r2 + shift) % 5][c2]

        else:
            # Rectangle rule: exchange the column positions
            result += matrix[r1][c2]
            result += matrix[r2][c1]

    return result


# Main program
keyword = input("Enter keyword: ")
plaintext = input("Enter plaintext: ")

matrix = create_matrix(keyword)

print("\nKey Matrix:")
for row in matrix:
    print(" ".join(row))

print("\nPrepared Pairs:", prepare_text(plaintext))

ciphertext = playfair(plaintext, matrix, True)
print("Encrypted Ciphertext:", ciphertext)

decrypted = playfair(ciphertext, matrix, False)
print("Decrypted Text:", decrypted)



"""